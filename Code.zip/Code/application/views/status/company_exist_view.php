<div class="alert alert-danger alert-dismissable" >
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
        <strong>Sorry!</strong> Company already exist.
</div>