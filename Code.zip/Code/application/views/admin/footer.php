<!-- BEGIN FOOTER -->
<div class="footer">
	<div class="footer-inner">
            2016 &copy; imis by <a target="_blank" href="http://www.facebook.com/aditya.7023">Aditya Shah</a> & <a target="_blank" href="http://www.facebook.com/palakdesai13">Palak Desai</a>.
	</div>
	<div class="footer-tools">
		<span class="go-top">
		<i class="fa fa-angle-up"></i>
		</span>
	</div>
</div>
<!-- END FOOTER -->